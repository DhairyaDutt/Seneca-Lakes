function showOverlay(cardElement) {
    // Toggle the overlay visibility
    cardElement.classList.toggle('show-overlay');
}